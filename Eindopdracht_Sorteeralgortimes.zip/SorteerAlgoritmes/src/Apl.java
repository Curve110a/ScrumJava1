import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Apl{

    public static void main(String[] args){
        String woorden = "";
        ArrayList<SorteerAlgoritme> sorteerAlgoritmes = new ArrayList<>();

        woorden=haalWoordenOp("sorteeralgoritmes.txt", sorteerAlgoritmes);

        printSorteerAlgoritmes(sorteerAlgoritmes);


    }
    public static void voegSorteerAlgoritmeToe (ArrayList<SorteerAlgoritme> sorteerAlgoritmes, SorteerAlgoritme sA){
        sorteerAlgoritmes.add(sA);
    }

    public static void printSorteerAlgoritmes(ArrayList<SorteerAlgoritme> sorteerAlgoritmes){
        for(int i=0; i<sorteerAlgoritmes.size(); i++){
            System.out.println("Sorteeralgoritme: " + sorteerAlgoritmes.get(i).getNaam() + "\n");
        }
    }

    public static String haalWoordenOp(String bestandnaam, ArrayList<SorteerAlgoritme> sorteerAlgoritmes){
        ArrayList woorden = new ArrayList();
        String woord = "";
        int index,aantalWoorden=0;

        BufferedReader in;
        String regel;
        try {
            in = new BufferedReader( new FileReader(bestandnaam) );
            while ((regel = in.readLine() ) != null) {
                //System.out.println( regel );
                //System.out.println("regel"+ regel);
                sorteerAlgoritmes.add(new SorteerAlgoritme(regel));
            }
            try {
                woorden.add(regel);
                aantalWoorden++;
            }catch (Exception e){
                e.printStackTrace();
            }
            in.close();
        } catch (FileNotFoundException e){
            System.out.println("Kan gegeven bestand niet vinden");
        } catch (IOException ioe){
            System.out.println("Fout bij het lezen of sluiten bestand");
        } catch(Exception e){
            e.printStackTrace();
        }
        index = (int) (Math.random()*aantalWoorden-1);
        //System.out.println(""+index+"    aantalwoorden "+aantalWoorden);
        woord = (String) woorden.get(index);

        return (woord);
    }
}


