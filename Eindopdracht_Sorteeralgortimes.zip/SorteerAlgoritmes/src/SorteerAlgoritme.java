public class SorteerAlgoritme{
    private String naam;

    public SorteerAlgoritme(String naam){
        this.naam = naam;
    }

    public String getNaam( ){
        return naam;
    }


}
