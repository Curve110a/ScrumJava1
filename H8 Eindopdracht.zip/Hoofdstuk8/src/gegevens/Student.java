package gegevens;
import kalender.datum;

public class Student {
	public String naam;
	public datum geboorteDatum;
	// hier worden 2 atributen aan gemaakt voor de gegevens van de studenten.
	// de geboortedatum wordt vanaf een andere package geimporteerd
	public static void main(String[] args) {

		Student student1 = new Student();
		student1.naam = "Emma";
		student1.geboorteDatum = new datum(28,8,1998);

		Student student2 = new Student();
		student2.naam = "David";
		student2.geboorteDatum = new datum(13,9,1996);
		/* hierboven worden 2 nieuwe objecten aangemaakt student 1 en student 2
		 * deze krijgen de naam emma en david en deze krijgen alle 2 een geboorte datum
		 */

		System.out.println("--Eerste Student--");
		System.out.println("Naam: "+ student1.naam);
		System.out.println("Geboorte datum:" + student1.geboorteDatum.datumFormaat());
		/* hierboven worden de gegevens van student 1 uitgeprint.
		 * de geboortedatum wordt met datumformaat in de datum form gezet. hoe dit gebeurt staat in het geimporteerde bestand
		 */ 
		System.out.println("");
		System.out.println("--Tweede Student--");
		System.out.println("Naam: "+ student2.naam);
		System.out.println("Geboorte datum:" + student2.geboorteDatum.datumFormaat());
	}

}
