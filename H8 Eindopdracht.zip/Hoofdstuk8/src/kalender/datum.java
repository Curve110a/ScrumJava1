package kalender;

public class datum{
	private int dag;
	private int maand;
	private int jaar;
	// hier woorden de atributen aangemaakt voor de geboortedatum

	public datum(int dag, int maand, int jaar){
		this.dag=dag;
		this.maand=maand;
		this.jaar=jaar;
		// hier worden de atributen ingesteld
	}

	public String datumFormaat() {

		return dag + "-"+ maand + "-"+jaar;
		// deze code zorgt er voor dat de ingevulde gegevens voor de gebortedatum in het goede formaat wordt uitgeprint
	}

}




