package quiz6;

public class Quiz6 {

	void myMethod() {
		String strArray[] = {"n","b","a","z"};
		for(int i = 0; i < strArray.length; i++) {
			if(strArray[i].equals("z")) {
				System.out.print("x1 ");
			} else if(strArray[i].equals("a")) {
				System.out.print("x2 ");
				//else if (strArray[i].equals("B")){
			}else if(strArray[i].equals("b")) {
				System.out.print("x2 ");
			}else {
				System.out.print("x3 ");
			}
		}
	}
	
	public static void main(String[] args) {
		Quiz6 q6 = new Quiz6();
		q6.myMethod();
	}
	
}
