package tools.package_02;

public class KlasseB {
public int w=1;
public int x = 2;
public int y = 3;
public int z = 4;

public void mijnMethode() {
//	System.out.print(w);
//	System.out.print(x);
//	System.out.print(y);
//	System.out.print(z);
}
}
