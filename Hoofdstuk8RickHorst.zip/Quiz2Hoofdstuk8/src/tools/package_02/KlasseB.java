package tools.package_02;

public class KlasseB {
	public int mijnInt = 1;
	public int w = 1;
	protected int x = 2;
	int y = 3;
	private int z = 4;
			
}
